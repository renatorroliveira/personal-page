package net.globalrelay.codeassignments.servicesmonitor.beans;

import java.util.Arrays;

import org.json.JSONException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.google.gson.Gson;

@RunWith(SpringRunner.class)
@SpringBootTest
public class RestResponsesTest {

	@Autowired private Gson gson;
	
	@Test
	public void testFailureReponse() throws JSONException {
		FailureResponse<String> response = new FailureResponse<>("Testing", 400);
		String json = this.gson.toJson(response);
		JSONAssert.assertEquals("{\"success\":false,\"message\":\"Testing\",\"status\":400}", json, false);
	}
	@Test
	public void testListReponse() throws JSONException {
		ListResponse<String> response = new ListResponse<>(Arrays.asList("Test 1", "Test 2"));
		String json = this.gson.toJson(response);
		JSONAssert.assertEquals("{\"success\":true,\"data\":[\"Test 1\", \"Test 2\"]}", json, false);
	}
	@Test
	public void testSuccessReponse() throws JSONException {
		SuccessResponse<String> response = new SuccessResponse<>("Testing");
		String json = this.gson.toJson(response);
		JSONAssert.assertEquals("{\"success\":true,\"data\":\"Testing\"}", json, false);
	}
}
