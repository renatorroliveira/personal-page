package net.globalrelay.codeassignments.servicesmonitor.monitoring;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.ResultActions;

import net.globalrelay.codeassignments.servicesmonitor.RestIntegrationTests;
import net.globalrelay.codeassignments.servicesmonitor.ServicesMonitor;
import net.globalrelay.codeassignments.servicesmonitor.beans.SuccessResponse;
import net.globalrelay.codeassignments.servicesmonitor.notification.NotificationTypes;
import net.globalrelay.codeassignments.servicesmonitor.service.Service;

/**
 * Integgration tests for the REST API of service entity.
 * @author Renato Oliveira
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes= {ServicesMonitor.class})
@AutoConfigureMockMvc
public class MonitoringControllerTest extends RestIntegrationTests {

	final Service service = generateService();
	List<ScheduledOutage> outages;
	List<Subscriber> subscribers;
	
	@Before
	public void populateDatabase() {
		try {
			this.saveService(this.service);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		
		this.outages = generateOutages(this.service);
		this.subscribers = generateSubscribers(this.service);

		this.outages.forEach((outage) -> {
			try {
				this.saveOutage(outage);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		});
		this.subscribers.forEach((sub) -> {
			try {
				this.saveSubscriber(sub);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		});
	}
	
	@After
	public void cleanDatabase() {
		this.outages.forEach((outage) -> {
			try {
				this.deleteRequest(String.format("/api/outages/%d", outage.getId()));
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		});
		this.subscribers.forEach((sub) -> {
			try {
				this.deleteRequest(String.format("/api/subscribers/%d", sub.getId()));
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		});
	}

	@Test
	public void outageCreationShouldReturnSavedSubscriber()  throws Exception {
		final ScheduledOutage outage = generateActiveOutage(this.service);
		this.saveOutage(outage);
		this.deleteRequest(String.format("/api/outages/%d", outage.getId()))
			.andExpect(status().isOk())
			.andExpect(content().json("{\"success\": true}"))
		;
	}

	@Test
	public void outageDeleteShouldRemoveAndReturnSubscriber()  throws Exception {
		final ScheduledOutage outage = this.outages.get(0);
		final String endpointUrl = String.format("/api/outages/%d", outage.getId());
		this.deleteRequest(endpointUrl)
			.andExpect(content().json(this.gson.toJson(new OutageResponse(outage))))
		;
		this.getRequest(endpointUrl)
			.andExpect(content().json("{\"success\":false,\"status\":404}"))
		;
	}

	@Test
	public void outageDeleteShouldReturnNotFound()  throws Exception {
		this.deleteRequest("/api/outages/100000")
			.andExpect(content().json("{\"success\":false,\"status\":404}"))
		;
	}

	@Test
	public void outageListingShouldReturnSavedSubscribers()  throws Exception {
		final ResultActions result = this.getRequest("/api/outages");
		result.andExpect(content().json("{\"success\":true}"));
	}
	
	@Test
	public void outageRetrieveShouldReturnSubscriber()  throws Exception {
		final ScheduledOutage outage = this.outages.get(0);
		this.getRequest(String.format("/api/outages/%d", outage.getId()))
			.andExpect(content().json(this.gson.toJson(new OutageResponse(outage))))
		;
	}
	
	@Test
	public void outageRetrieveShouldReturnServiceNotFound()  throws Exception {
		this.getRequest("/api/outages/100000")
			.andExpect(content().json("{\"success\":false,\"status\":404}"))
		;
	}

	@Test
	public void subscriberCreationShouldReturnSavedSubscriber()  throws Exception {
		final Subscriber sub = generateSubscriber(this.service);
		this.saveSubscriber(sub);
		this.deleteRequest(String.format("/api/subscribers/%d", sub.getId()))
			.andExpect(status().isOk())
			.andExpect(content().json("{\"success\": true}"))
		;
	}

	@Test
	public void subscriberDeleteShouldRemoveAndReturnSubscriber()  throws Exception {
		final Subscriber sub = this.subscribers.get(0);
		final String endpointUrl = String.format("/api/subscribers/%d", sub.getId());
		this.deleteRequest(endpointUrl)
			.andExpect(content().json(this.gson.toJson(new SubscriberResponse(sub))))
		;
		this.getRequest(endpointUrl)
			.andExpect(content().json("{\"success\":false,\"status\":404}"))
		;
	}

	@Test
	public void subscriberDeleteShouldReturnNotFound()  throws Exception {
		this.deleteRequest("/api/subscribers/100000")
			.andExpect(content().json("{\"success\":false,\"status\":404}"))
		;
	}

	@Test
	public void subscriberListingShouldReturnSavedSubscribers()  throws Exception {
		final ResultActions result = this.getRequest("/api/subscribers");
		result.andExpect(content().json("{\"success\":true}"));
	}
	
	@Test
	public void subscriberRetrieveShouldReturnSubscriber()  throws Exception {
		final Subscriber sub = this.subscribers.get(0);
		this.getRequest(String.format("/api/subscribers/%d", sub.getId()))
			.andExpect(content().json(this.gson.toJson(new SubscriberResponse(sub))))
		;
	}
	
	@Test
	public void subscriberRetrieveShouldReturnServiceNotFound()  throws Exception {
		this.getRequest("/api/subscribers/100000")
			.andExpect(content().json("{\"success\":false,\"status\":404}"))
		;
	}

	private static Service generateService() {
		final Service service = new Service("SSL Homepage", "www.renatorro.com", 443);
		service.setCreated(null);
		return service;
	}
	private static ScheduledOutage generateActiveOutage(Service service) {
		final LocalDateTime now = LocalDateTime.now();
		final LocalDateTime from = now.minus(2, ChronoUnit.DAYS);
		final LocalDateTime to = now.plus(2, ChronoUnit.DAYS);
		final ScheduledOutage outage = new ScheduledOutage(
			Date.from(from.atZone(ZoneId.systemDefault()).toInstant()),
			Date.from(to.atZone(ZoneId.systemDefault()).toInstant()),
			service
		);
		outage.setCreated(null);
		return outage;
	}
	private static ScheduledOutage generateInactiveOutage(Service service) {
		final LocalDateTime now = LocalDateTime.now();
		final LocalDateTime from = now.minus(10, ChronoUnit.DAYS);
		final LocalDateTime to = now.minus(8, ChronoUnit.DAYS);
		final ScheduledOutage outage = new ScheduledOutage(
			Date.from(from.atZone(ZoneId.systemDefault()).toInstant()),
			Date.from(to.atZone(ZoneId.systemDefault()).toInstant()),
			service
		);
		outage.setCreated(null);
		return outage;
	}
	
	private static Subscriber generateSubscriber(Service service) {
		return new Subscriber("Renato (E-mail)", NotificationTypes.EMAIL, "renatorro@comp.ufla.br", service);
	}
	
	private static List<ScheduledOutage> generateOutages(Service service) {
		List<ScheduledOutage> outages = new ArrayList<>(3);
		outages.add(generateActiveOutage(service));
		outages.add(generateInactiveOutage(service));
		return outages;
	}
	
	private static List<Subscriber> generateSubscribers(Service service) {
		List<Subscriber> subscribers = new ArrayList<>(3);
		subscribers.add(generateSubscriber(service));
		subscribers.add(new Subscriber("Enterprise E-mail", NotificationTypes.EMAIL, "ti@enterprise.net", service));
		subscribers.add(new Subscriber("Enterprise Webhook", NotificationTypes.WEBHOOK, "http://handle.enterprise.net", service));
		return subscribers;
	}
	
	protected void saveOutage(ScheduledOutage outage) throws Exception {
		final ResultActions result =  mvc.perform(post("/api/outages")
				.accept(MediaType.APPLICATION_JSON_UTF8)
				.content(this.gson.toJson(outage))
				.contentType(MediaType.APPLICATION_JSON_UTF8)
			)
			.andExpect(status().isOk())
			.andExpect(content().json("{\"success\": true}"))
		;
		final OutageResponse response = this.gson.fromJson(result.andReturn().getResponse().getContentAsString(), OutageResponse.class);
		outage.setId(response.getData().getId());
	}
	
	protected void saveSubscriber(Subscriber sub) throws Exception {
		final ResultActions result =  mvc.perform(post("/api/subscribers")
				.accept(MediaType.APPLICATION_JSON_UTF8)
				.content(this.gson.toJson(sub))
				.contentType(MediaType.APPLICATION_JSON_UTF8)
			)
			.andExpect(status().isOk())
			.andExpect(content().json("{\"success\": true}"))
		;
		final SubscriberResponse response = this.gson.fromJson(result.andReturn().getResponse().getContentAsString(), SubscriberResponse.class);
		sub.setId(response.getData().getId());
	}

	
	static class OutageResponse extends SuccessResponse<ScheduledOutage> {
		private static final long serialVersionUID = 1L;
		OutageResponse(ScheduledOutage outage) {
			super(outage);
		}
	}
	static class SubscriberResponse extends SuccessResponse<Subscriber> {
		private static final long serialVersionUID = 1L;
		SubscriberResponse(Subscriber sub) {
			super(sub);
		}
	}
}
