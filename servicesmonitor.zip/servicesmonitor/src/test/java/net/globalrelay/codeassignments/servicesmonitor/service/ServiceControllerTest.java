package net.globalrelay.codeassignments.servicesmonitor.service;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.ResultActions;

import net.globalrelay.codeassignments.servicesmonitor.RestIntegrationTests;

/**
 * Integgration tests for the REST API of service entity.
 * @author Renato Oliveira
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class ServiceControllerTest extends RestIntegrationTests {
	
	final List<Service> services = generateServices();
	
	@Before
	public void populateDatabase() {
		services.forEach((service) -> {
			try {
				this.saveService(service);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		});
	}
	
	@After
	public void cleanDatabase() {
		services.forEach((service) -> {
			try {
				this.deleteRequest(String.format("/api/services/%d", service.getId()));
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		});
	}

	@Test
	public void serviceCreationShouldReturnSavedService()  throws Exception {
		final Service service = generateService();
		this.saveService(service);
		this.deleteRequest(String.format("/api/services/%d", service.getId()))
			.andExpect(status().isOk())
			.andExpect(content().json("{\"success\":true}"))
		;
	}

	@Test
	public void serviceDeleteShouldRemoveAndReturnService()  throws Exception {
		final Service service = this.services.get(0);
		final String endpointUrl = String.format("/api/services/%d", service.getId());
		this.deleteRequest(endpointUrl)
			.andExpect(content().json(this.gson.toJson(new ServiceResponse(service))))
		;
		this.getRequest(endpointUrl)
			.andExpect(content().json("{\"success\":false,\"status\":404}"))
		;
	}

	@Test
	public void serviceDeleteShouldReturnNotFound()  throws Exception {
		this.deleteRequest("/api/services/100000")
			.andExpect(content().json("{\"success\":false,\"status\":404}"))
		;
	}

	@Test
	public void serviceListingShouldReturnSavedServices()  throws Exception {
		final ResultActions result = this.getRequest("/api/services");
		result.andExpect(content().json("{\"success\":true}"));
	}
	
	@Test
	public void serviceRetrieveShouldReturnService()  throws Exception {
		final Service service = this.services.get(0);
		this.getRequest(String.format("/api/services/%d", service.getId()))
			.andExpect(content().json(this.gson.toJson(new ServiceResponse(service))))
		;
	}
	
	@Test
	public void serviceRetrieveShouldReturnServiceNotFound()  throws Exception {
		this.getRequest("/api/services/100000")
			.andExpect(content().json("{\"success\":false,\"status\":404}"))
		;
	}

	private static Service generateService() {
		final Service service = new Service("Google", "www.google.com", 443);
		service.setCreated(null);
		return service;
	}
	private static List<Service> generateServices() {
		List<Service> services = new ArrayList<>(4);
		services.add(generateService());
		
		Service service = new Service("Facebook", "www.facebook.com", 80);
		service.setCreated(null);
		services.add(service);
		
		service = new Service("Twitter", "www.twitter.com", 80);
		service.setCreated(null);
		services.add(service);
		
		service = new Service("Google Mail", "mail.google.com", 80);
		service.setCreated(null);
		services.add(service);
		return services;
	}
	
}
