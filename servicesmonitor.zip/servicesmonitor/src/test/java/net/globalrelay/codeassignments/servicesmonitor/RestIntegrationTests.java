package net.globalrelay.codeassignments.servicesmonitor;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import com.google.gson.Gson;

import net.globalrelay.codeassignments.servicesmonitor.beans.SuccessResponse;
import net.globalrelay.codeassignments.servicesmonitor.service.Service;

public abstract class RestIntegrationTests {
	
	@Autowired protected MockMvc mvc;
	@Autowired protected Gson gson;

	protected ResultActions deleteRequest(String url) throws Exception {
		return mvc.perform(delete(url)
				.accept(MediaType.APPLICATION_JSON_UTF8)
			)
			.andExpect(status().isOk())
		;
	}
	
	protected ResultActions getRequest(String url) throws Exception {
		return mvc.perform(get(url)
				.accept(MediaType.APPLICATION_JSON_UTF8)
			)
			.andExpect(status().isOk())
		;
	}
	
	protected void saveService(Service service) throws Exception {
		final ResultActions result =  mvc.perform(post("/api/services")
				.accept(MediaType.APPLICATION_JSON_UTF8)
				.content(this.gson.toJson(service))
				.contentType(MediaType.APPLICATION_JSON_UTF8)
			)
			.andExpect(status().isOk())
			.andExpect(content().json("{\"success\": true}"))
		;
		final ServiceResponse response = this.gson.fromJson(result.andReturn().getResponse().getContentAsString(), ServiceResponse.class);
		service.setId(response.getData().getId());
	}

	protected static class ServiceResponse extends SuccessResponse<Service> {
		private static final long serialVersionUID = 1L;
		public ServiceResponse(Service service) {
			super(service);
		}
	}
}
