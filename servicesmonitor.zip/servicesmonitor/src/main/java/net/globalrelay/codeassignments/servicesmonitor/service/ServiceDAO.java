package net.globalrelay.codeassignments.servicesmonitor.service;

import org.springframework.stereotype.Repository;

import net.globalrelay.codeassignments.servicesmonitor.DAO;

@Repository
public interface ServiceDAO extends DAO<Service>, ServiceRepository {

}
