package net.globalrelay.codeassignments.servicesmonitor.notification;

import java.io.BufferedOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.jboss.logging.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.http.MediaType;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import net.globalrelay.codeassignments.servicesmonitor.SkipSerializationStrategy;
import net.globalrelay.codeassignments.servicesmonitor.monitoring.Subscriber;

public class WebHookNotifier implements Notifier {
	private static final Logger LOG = Logger.getLogger(WebHookNotifier.class);

	private final Gson gson = new GsonBuilder()
		.addSerializationExclusionStrategy(new SkipSerializationStrategy())
		.enableComplexMapKeySerialization()
		.setPrettyPrinting()
		.create()
	;
	@Override
	public void notify(Subscriber subscriber, ApplicationContext context) {
		try {
			HttpURLConnection conn = (HttpURLConnection) new URL(subscriber.getNotificationParams()).openConnection();
			conn.setRequestMethod("POST");
			conn.addRequestProperty("Content-type", MediaType.APPLICATION_JSON_UTF8_VALUE);
			conn.setDoOutput(true);
			conn.connect();
			
			OutputStream output = new BufferedOutputStream(conn.getOutputStream(), 4096);
			String data = this.gson.toJson(subscriber);
			output.write(data.getBytes("UTF-8"));
			output.close();
			conn.disconnect();
		} catch (Exception e) {
			LOG.errorf(e, "Failed to send webhook notification: %s", subscriber.getNotificationParams());
		}
	}
	
}
