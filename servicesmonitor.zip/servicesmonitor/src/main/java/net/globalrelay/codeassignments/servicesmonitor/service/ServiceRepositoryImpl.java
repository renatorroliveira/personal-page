package net.globalrelay.codeassignments.servicesmonitor.service;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.ParameterExpression;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class ServiceRepositoryImpl implements ServiceRepository {

	@PersistenceContext private EntityManager em;
	
	@Override
	@Transactional
	public Service saveService(Service service) {
		Service existent = this.retrieveByHostAndPort(service.getHost(), service.getPort());
		if (existent != null) {
			existent.setDownReason(service.getDownReason());
			existent.setLabel(service.getLabel());
			existent.setLastDownTime(service.getLastDownTime());
			existent.setLastPoll(service.getLastPoll());
			existent.setUp(service.isUp());
			this.em.persist(existent);
			return existent;
		} else {
			service.setId(null);
			this.em.persist(service);
			return service;
		}
	}
	
	@Override
	public Service retrieveByHostAndPort(String host, int port) {
		final CriteriaBuilder builder = this.em.getCriteriaBuilder();
		final CriteriaQuery<Service> criteria = builder.createQuery(Service.class);
		final Root<Service> serviceTable = criteria.from(Service.class);
		final ParameterExpression<String> hostParam = builder.parameter(String.class);
		final ParameterExpression<Integer> portParam = builder.parameter(Integer.class);
		criteria
			.select(serviceTable)
			.where(
				builder.and(
					builder.equal(serviceTable.get("host"), hostParam),
					builder.equal(serviceTable.get("port"), portParam)
				)
			)
		;
		try {
			return this.em.createQuery(criteria)
				.setParameter(hostParam, host)
				.setParameter(portParam, port)
				.getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

}
