package net.globalrelay.codeassignments.servicesmonitor.monitoring;

import org.springframework.stereotype.Repository;

import net.globalrelay.codeassignments.servicesmonitor.DAO;

@Repository
public interface ScheduledOutageDAO extends DAO<ScheduledOutage> {

}
