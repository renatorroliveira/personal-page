package net.globalrelay.codeassignments.servicesmonitor.monitoring;

import org.springframework.stereotype.Repository;

import net.globalrelay.codeassignments.servicesmonitor.DAO;

@Repository
public interface SubscriberDAO extends DAO<Subscriber> {

}
