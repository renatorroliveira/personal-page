package net.globalrelay.codeassignments.servicesmonitor.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.globalrelay.codeassignments.servicesmonitor.beans.FailureResponse;
import net.globalrelay.codeassignments.servicesmonitor.beans.ListResponse;
import net.globalrelay.codeassignments.servicesmonitor.beans.RestResponse;
import net.globalrelay.codeassignments.servicesmonitor.beans.SuccessResponse;

@RestController
@CrossOrigin
@RequestMapping(path="/api/services", produces=MediaType.APPLICATION_JSON_UTF8_VALUE)
public class ServiceController {
	
	@Autowired
	private ServiceBusiness business;

	@PostMapping(value="", consumes=MediaType.APPLICATION_JSON_UTF8_VALUE)
	public RestResponse<?> create(@RequestBody Service service) {
		return new SuccessResponse<>(this.business.persist(service));
	}
	
	@DeleteMapping("/{id}")
	public RestResponse<?> delete(@PathVariable("id") Long id) {
		final Service service = this.business.delete(id);
		if (service == null) {
			return new FailureResponse<>("Service not found.", 404);
		}
		return new SuccessResponse<>(service);
	}

	@GetMapping(value="")
	public RestResponse<?> find() {
		return new ListResponse<>(this.business.listAll());
	}

	@GetMapping("/{id}")
	public RestResponse<?> retrieveService(@PathVariable("id") Long id) {
		final Service service = this.business.retrieve(id);
		if (service == null) {
			return new FailureResponse<>("Service not found.", 404);
		}
		return new SuccessResponse<>(service);
	}
}
