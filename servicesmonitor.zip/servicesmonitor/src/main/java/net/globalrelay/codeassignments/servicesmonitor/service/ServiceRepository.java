package net.globalrelay.codeassignments.servicesmonitor.service;

import org.springframework.transaction.annotation.Transactional;

public interface ServiceRepository {
	@Transactional Service saveService(Service service);
	Service retrieveByHostAndPort(String host, int port);
}
