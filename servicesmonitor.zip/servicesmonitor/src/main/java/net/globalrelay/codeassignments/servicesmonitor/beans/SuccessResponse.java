package net.globalrelay.codeassignments.servicesmonitor.beans;

import java.io.Serializable;

public class SuccessResponse<T extends Serializable> extends RestResponse<T> {
	private static final long serialVersionUID = 1L;

	public SuccessResponse(T data) {
		super(data, true, null, 200);
	}
}
