package net.globalrelay.codeassignments.servicesmonitor.monitoring;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.ParameterExpression;
import javax.persistence.criteria.Root;

import net.globalrelay.codeassignments.servicesmonitor.service.Service;

@org.springframework.stereotype.Service
public class MonitoringBusiness {

	private final ScheduledOutageDAO outageDao;
	private final SubscriberDAO subscriberDao;
	private final EntityManager em;
	
	public MonitoringBusiness(ScheduledOutageDAO outageDao, SubscriberDAO dao, EntityManager em) {
		this.outageDao = outageDao;
		this.subscriberDao = dao;
		this.em = em;
	}

	public Long countActiveOutagesByService(Service service) {
		CriteriaBuilder builder = this.em.getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		Root<ScheduledOutage> outagesTable = criteria.from(ScheduledOutage.class);
		ParameterExpression<Service> serviceId = builder.parameter(Service.class);
		criteria
			.select(builder.count(outagesTable))
			.where(
				builder.and(
					builder.equal(outagesTable.get("service"), serviceId),
					builder.between(builder.currentTimestamp(), outagesTable.get("begin"), outagesTable.get("end"))
				)
			)
		;
		return this.em.createQuery(criteria).setParameter(serviceId, service).getSingleResult();
	}

	public ScheduledOutage deleteOutage(Long id) {
		ScheduledOutage outage = this.retrieveOutage(id);
		if (outage == null) {
			return null;
		}
		this.outageDao.delete(outage);
		return outage;
	}
	
	public Subscriber deleteSubscriber(Long id) {
		Subscriber subscriber = this.retrieveSubscriber(id);
		if (subscriber == null) {
			return null;
		}
		this.subscriberDao.delete(subscriber);
		return subscriber;
	}

	public List<ScheduledOutage> listAllOutages() {
		return this.outageDao.findAll();
	}
	public List<Subscriber> listAllSubscribers() {
		return this.subscriberDao.findAll();
	}

	public List<ScheduledOutage> listOutagesByService(Service service) {
		CriteriaBuilder builder = this.em.getCriteriaBuilder();
		CriteriaQuery<ScheduledOutage> criteria = builder.createQuery(ScheduledOutage.class);
		Root<ScheduledOutage> outagesTable = criteria.from(ScheduledOutage.class);
		ParameterExpression<Service> serviceId = builder.parameter(Service.class);
		criteria
			.select(outagesTable)
			.where(
				builder.equal(outagesTable.get("service"), serviceId)
			)
		;
		return this.em.createQuery(criteria).setParameter(serviceId, service).getResultList();
	}
	
	public List<Subscriber> listSubscribersByService(Service service) {
		CriteriaBuilder builder = this.em.getCriteriaBuilder();
		CriteriaQuery<Subscriber> criteria = builder.createQuery(Subscriber.class);
		Root<Subscriber> subscriberTable = criteria.from(Subscriber.class);
		ParameterExpression<Service> serviceId = builder.parameter(Service.class);
		criteria
			.select(subscriberTable)
			.where(
				builder.equal(subscriberTable.get("service"), serviceId)
			)
		;
		return this.em.createQuery(criteria).setParameter(serviceId, service).getResultList();
	}

	public ScheduledOutage persist(ScheduledOutage outage) {
		return this.outageDao.save(outage);
	}
	public Subscriber persist(Subscriber subscriber) {
		return this.subscriberDao.save(subscriber);
	}

	public ScheduledOutage retrieveOutage(Long id) {
		if (id == null)
			return null;
		return this.outageDao.findById(id).orElse(null);
	}
	
	public Subscriber retrieveSubscriber(Long id) {
		if (id == null)
			return null;
		return this.subscriberDao.findById(id).orElse(null);
	}
}
