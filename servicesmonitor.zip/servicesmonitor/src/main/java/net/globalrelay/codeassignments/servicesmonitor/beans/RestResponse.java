package net.globalrelay.codeassignments.servicesmonitor.beans;

import java.io.Serializable;

public class RestResponse<T> implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private final T data;
	private final boolean success;
	private final String message;
	private final int status;
	
	public RestResponse(T data, boolean success, String message, int status) {
		this.data = data;
		this.success = success;
		this.message = message;
		this.status = status;
	}

	public T getData() {
		return data;
	}

	public boolean isSuccess() {
		return success;
	}

	public String getMessage() {
		return message;
	}

	public int getStatus() {
		return status;
	}
}
