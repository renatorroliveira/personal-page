package net.globalrelay.codeassignments.servicesmonitor.monitoring;

import java.util.List;

import org.jboss.logging.Logger;
import org.springframework.context.ApplicationContext;

import net.globalrelay.codeassignments.servicesmonitor.notification.NotificationTypes;
import net.globalrelay.codeassignments.servicesmonitor.service.Service;
import net.globalrelay.codeassignments.servicesmonitor.service.ServiceBusiness;

public class ServiceStatusChecker implements Runnable {
	private static final Logger LOG = Logger.getLogger(ServiceStatusChecker.class);

	private final Service service;
	private final MonitoringBusiness monitoringBusiness;
	private final ServiceBusiness serviceBusiness;
	private final ApplicationContext context;
	
	public ServiceStatusChecker(Service service, MonitoringBusiness monitoringBusiness, ServiceBusiness serviceBusiness, ApplicationContext context) {
		this.service = service;
		this.monitoringBusiness = monitoringBusiness;
		this.serviceBusiness = serviceBusiness;
		this.context = context;
	}
	
	@Override
	public void run() {
		LOG.infof("Executing service checking for service: %s", service.getLabel());
		final long current = System.currentTimeMillis();
		service.setLastPoll(current);
		this.serviceBusiness.persist(service);
		final boolean wasUp = service.isUp();
		final String downReason = MonitoringHelper.checkTcpConnection(service.getHost(), service.getPort());
		if (downReason == null) {
			service.setUp(true);
		} else {
			if (service.isUp()) {
				service.setLastDownTime(current);
			}
			service.setUp(false);
		}
		service.setDownReason(downReason);
		this.serviceBusiness.persist(service);

		final MonitoringBusiness business = this.context.getBean(MonitoringBusiness.class);
		if (!service.isUp() && (this.monitoringBusiness.countActiveOutagesByService(service) == 0)) {
			List<Subscriber> subscribers = business.listSubscribersByService(service);
			for (Subscriber sub : subscribers) {
				if (!sub.isNotificationSent() && (sub.getGraceInterval() < (current - service.getLastDownTime()))) {
					NotificationTypes notificationType = NotificationTypes.valueOf(sub.getNotificationType());
					notificationType.getNotifier().notify(sub, context);
					sub.setNotificationSent(true);
					business.persist(sub);
				}
			}
		} else if (!wasUp && service.isUp()) {
			List<Subscriber> subscribers = business.listSubscribersByService(service);
			for (Subscriber sub : subscribers) {
				sub.setNotificationSent(false);
				business.persist(sub);
			}
		}
	}

}
