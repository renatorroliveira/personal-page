package net.globalrelay.codeassignments.servicesmonitor.beans;

import java.io.Serializable;

public class FailureResponse<T extends Serializable> extends RestResponse<T> {
	private static final long serialVersionUID = 1L;

	public FailureResponse(String message) {
		this(message, 400);
	}
	public FailureResponse(String message, int status) {
		super(null, false, message, status);
	}
}
