package net.globalrelay.codeassignments.servicesmonitor.notification;

import org.springframework.context.ApplicationContext;

import net.globalrelay.codeassignments.servicesmonitor.monitoring.Subscriber;

@FunctionalInterface
public interface Notifier {
	public void notify(Subscriber subscriber, ApplicationContext context);
}
