package net.globalrelay.codeassignments.servicesmonitor.monitoring;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import net.globalrelay.codeassignments.servicesmonitor.JpaModel;
import net.globalrelay.codeassignments.servicesmonitor.service.Service;

@Entity
@Table(name="scheduled_outages")
public class ScheduledOutage extends JpaModel {
	private static final long serialVersionUID = 1L;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable=false, updatable=false)
	private Date created = new Date();

	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable=false)
	private Date begin;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable=false)
	private Date end;
	
	@ManyToOne(targetEntity=Service.class, fetch=FetchType.EAGER, optional=false)
	private Service service;

	public ScheduledOutage() {
		
	}
	public ScheduledOutage(Date begin, Date end, Service service) {
		this.begin = begin;
		this.end = end;
		this.service = service;
	}
	
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public Date getBegin() {
		return begin;
	}
	public void setBegin(Date begin) {
		this.begin = begin;
	}
	public Date getEnd() {
		return end;
	}
	public void setEnd(Date end) {
		this.end = end;
	}
	public Service getService() {
		return service;
	}
	public void setService(Service service) {
		this.service = service;
	}
	
}
