package net.globalrelay.codeassignments.servicesmonitor.monitoring;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import net.globalrelay.codeassignments.servicesmonitor.JpaModel;
import net.globalrelay.codeassignments.servicesmonitor.notification.NotificationTypes;
import net.globalrelay.codeassignments.servicesmonitor.service.Service;

@Entity
@Table(name="subscribers")
public class Subscriber extends JpaModel {
	private static final long serialVersionUID = 1L;

	private String label;
	
	@Column(nullable=false)
	private String notificationType = NotificationTypes.NONE.name();
	private String notificationParams;
	private boolean notificationSent = false;
	
	/** Polling interval in miliseconds */
	private long pollingInterval = 30000;
	/** Grace Interval in seconds */
	private long graceInterval = 60000;
	
	@ManyToOne(targetEntity=Service.class, fetch=FetchType.EAGER, optional=false)
	private Service service;

	public Subscriber() {
		
	}
	public Subscriber(String label, NotificationTypes notificationType, String notificationParam, Service service) {
		this.label = label;
		this.notificationType = notificationType.name();
		this.notificationParams = notificationParam;
		this.service = service;
	}
	
	public String getNotificationType() {
		return notificationType;
	}

	public void setNotificationType(String notificationType) {
		this.notificationType = notificationType;
	}

	public String getNotificationParams() {
		return notificationParams;
	}

	public void setNotificationParams(String notificationParams) {
		this.notificationParams = notificationParams;
	}

	public long getPollingInterval() {
		return pollingInterval;
	}

	public void setPollingInterval(long pollingInterval) {
		this.pollingInterval = pollingInterval;
	}

	public long getGraceInterval() {
		return graceInterval;
	}

	public void setGraceInterval(long graceInterval) {
		this.graceInterval = graceInterval;
	}

	public Service getService() {
		return service;
	}

	public void setService(Service service) {
		this.service = service;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	public boolean isNotificationSent() {
		return notificationSent;
	}
	public void setNotificationSent(boolean notificationSent) {
		this.notificationSent = notificationSent;
	}
}
