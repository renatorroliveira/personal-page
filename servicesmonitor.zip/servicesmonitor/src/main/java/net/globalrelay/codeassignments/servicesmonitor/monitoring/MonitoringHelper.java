package net.globalrelay.codeassignments.servicesmonitor.monitoring;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;

public class MonitoringHelper {

	/**
	 * Checkls if a host/port pair is available for TCP connections.
	 * @param host The host or ip address for connection
	 * @param port The port for connection
	 * @return String The reason for connection failure, null if connection succeeded.
	 */
	public static String checkTcpConnection(String host, int port) {
		try {
			Socket socket = new Socket();
			socket.connect(new InetSocketAddress(host, port), 5000);
			socket.close();
			return null;
		} catch (IOException e) {
			return e.getMessage();
		}
	}
}
