package net.globalrelay.codeassignments.servicesmonitor.service;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import net.globalrelay.codeassignments.servicesmonitor.JpaModel;
import net.globalrelay.codeassignments.servicesmonitor.SkipSerialization;
import net.globalrelay.codeassignments.servicesmonitor.monitoring.ScheduledOutage;
import net.globalrelay.codeassignments.servicesmonitor.monitoring.Subscriber;

@Entity
@Table(
	name="service",
	uniqueConstraints= {
		@UniqueConstraint(columnNames={"host", "port"})
	}
)
public class Service extends JpaModel {
	private static final long serialVersionUID = 1L;

	@Column(nullable=true)
	private String label;
	
	private long lastPoll = System.currentTimeMillis();
	private long lastDownTime = System.currentTimeMillis();
	private boolean up = true;
	private String downReason;
	
	/** Service host to monitor */
	private String host;
	/** Service port to monitor */
	private int port = 80;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable=false, updatable=false)
	private Date created = new Date();

	@SkipSerialization
	@OneToMany(targetEntity=ScheduledOutage.class, fetch=FetchType.LAZY, mappedBy="service", orphanRemoval=true)
	public List<ScheduledOutage> outages;
	
	@SkipSerialization
	@OneToMany(targetEntity=Subscriber.class, fetch=FetchType.LAZY, mappedBy="service", orphanRemoval=true)
	public List<Subscriber> subscribers;
	
	public Service() {
		
	}
	public Service(String label, String host, int port) {
		this.label = label;
		this.host = host;
		this.port = port;
	}
	public Service(Service service) {
		super(service);
		this.label = service.label;
		this.host = service.host;
		this.port = service.port;
		this.lastPoll = service.lastPoll;
		this.lastDownTime = service.lastDownTime;
		this.up = service.up;
		this.downReason = service.downReason;
		this.created = service.created;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public long getLastPoll() {
		return lastPoll;
	}
	public void setLastPoll(long lastPoll) {
		this.lastPoll = lastPoll;
	}
	public long getLastDownTime() {
		return lastDownTime;
	}
	public void setLastDownTime(long lastDownTime) {
		this.lastDownTime = lastDownTime;
	}
	public boolean isUp() {
		return up;
	}
	public void setUp(boolean up) {
		this.up = up;
	}
	public String getDownReason() {
		return downReason;
	}
	public void setDownReason(String downReason) {
		this.downReason = downReason;
	}
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public List<Subscriber> getSubscribers() {
		return subscribers;
	}
	public List<ScheduledOutage> getOutages() {
		return outages;
	}

}
