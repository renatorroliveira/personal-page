package net.globalrelay.codeassignments.servicesmonitor.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.ParameterExpression;
import javax.persistence.criteria.Root;

import net.globalrelay.codeassignments.servicesmonitor.monitoring.Subscriber;

@org.springframework.stereotype.Service
public class ServiceBusiness {
	
	private final ServiceDAO dao;
	private final EntityManager em;
	
	public ServiceBusiness(ServiceDAO dao, EntityManager em) {
		this.dao = dao;
		this.em = em;
	}

	public Service delete(Long id) {
		Service service = this.retrieve(id);
		if (service == null) {
			return null;
		}
		this.dao.delete(service);
		return service;
	}
	
	public List<Service> listAll() {
		return this.dao.findAll();
	}
	
	public List<Service> listForMonitoring() {
		final long current = System.currentTimeMillis();
		final CriteriaBuilder builder = this.em.getCriteriaBuilder();
		final CriteriaQuery<Service> criteria = builder.createQuery(Service.class);
		final Root<Service> serviceTable = criteria.from(Service.class);
		final Join<Service, Subscriber> subscribersTable = serviceTable.joinList("subscribers", JoinType.INNER);
		final ParameterExpression<Long> currentTimeParam = builder.parameter(Long.class);
		criteria
			.select(serviceTable)
			.having(
				builder.or(
					builder.ge(currentTimeParam, builder.sum(
						serviceTable.get("lastPoll"),
						builder.min(subscribersTable.get("pollingInterval"))
					)),
					builder.and(
						builder.isFalse(serviceTable.get("up")),
						builder.ge(currentTimeParam, builder.sum(
							serviceTable.get("lastPoll"),
							builder.min(subscribersTable.get("graceInterval"))
						))
					)
				)
			)
			.groupBy(serviceTable)
		;
		return this.em.createQuery(criteria).setParameter(currentTimeParam, current).getResultList();
	}
	
	public Service persist(Service service) {
		return this.dao.saveService(service);
	}
	
	public Service retrieve(Long id) {
		if (id == null)
			return null;
		return this.dao.findById(id).orElse(null);
	}
	
}
