package net.globalrelay.codeassignments.servicesmonitor.beans;

import java.io.Serializable;
import java.util.List;

public class ListResponse<T extends Serializable> extends RestResponse<List<T>> {
	private static final long serialVersionUID = 1L;

	public ListResponse(List<T> data) {
		super(data, true, null, 200);
	}
}
