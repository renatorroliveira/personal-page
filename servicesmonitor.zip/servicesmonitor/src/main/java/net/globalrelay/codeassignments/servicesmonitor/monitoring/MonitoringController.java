package net.globalrelay.codeassignments.servicesmonitor.monitoring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.globalrelay.codeassignments.servicesmonitor.beans.FailureResponse;
import net.globalrelay.codeassignments.servicesmonitor.beans.ListResponse;
import net.globalrelay.codeassignments.servicesmonitor.beans.RestResponse;
import net.globalrelay.codeassignments.servicesmonitor.beans.SuccessResponse;
import net.globalrelay.codeassignments.servicesmonitor.service.Service;
import net.globalrelay.codeassignments.servicesmonitor.service.ServiceBusiness;

/**
 * REST API for monitoring related entities.
 * @author Renato Oliveira
 *
 */
@RestController
@CrossOrigin
@RequestMapping(path="/api", produces=MediaType.APPLICATION_JSON_UTF8_VALUE)
public class MonitoringController {
	
	@Autowired private MonitoringBusiness business;
	@Autowired private ServiceBusiness serviceBusiness;

	@PostMapping(value="/outages", consumes=MediaType.APPLICATION_JSON_UTF8_VALUE)
	public RestResponse<?> createOutage(@RequestBody ScheduledOutage outage) {
		if (outage == null || outage.getService() == null || outage.getService().getId() == null) {
			return new FailureResponse<>("Invalid data for scheduled outage.", 400);
		}
		final Service service = serviceBusiness.retrieve(outage.getService().getId());
		if (service == null) {
			return new FailureResponse<>("Service not found.", 404);
		}
		outage.setService(service);
		return new SuccessResponse<>(this.business.persist(outage));
	}

	@PostMapping(value="/subscribers", consumes=MediaType.APPLICATION_JSON_UTF8_VALUE)
	public RestResponse<?> createSubscriber(@RequestBody Subscriber sub) {
		if (sub == null || sub.getService() == null || sub.getService().getId() == null) {
			return new FailureResponse<>("Invalid data for subscriber.", 400);
		}
		final Service service = serviceBusiness.retrieve(sub.getService().getId());
		if (service == null) {
			return new FailureResponse<>("Service not found.", 404);
		}
		sub.setService(service);
		return new SuccessResponse<>(this.business.persist(sub));
	}
	
	@DeleteMapping("/outages/{id}")
	public RestResponse<?> deleteOutage(@PathVariable("id") Long id) {
		final ScheduledOutage outage = this.business.deleteOutage(id);
		if (outage == null) {
			return new FailureResponse<>("Scheduled outage not found.", 404);
		}
		return new SuccessResponse<>(outage);
	}
	
	@DeleteMapping("/subscribers/{id}")
	public RestResponse<?> deleteSubscriber(@PathVariable("id") Long id) {
		final Subscriber subscriber = this.business.deleteSubscriber(id);
		if (subscriber == null) {
			return new FailureResponse<>("Subscriber not found.", 404);
		}
		return new SuccessResponse<>(subscriber);
	}

	@GetMapping(value="/outages")
	public RestResponse<?> findOutages() {
		return new ListResponse<>(this.business.listAllOutages());
	}
	
	@GetMapping(value="/subscribers")
	public RestResponse<?> findSubscribers() {
		return new ListResponse<>(this.business.listAllSubscribers());
	}

	@GetMapping("/outages/{id}")
	public RestResponse<?> retrieveOutage(@PathVariable("id") Long id) {
		final ScheduledOutage outage = this.business.retrieveOutage(id);
		if (outage == null) {
			return new FailureResponse<>("Scheduled outage not found.", 404);
		}
		return new SuccessResponse<>(outage);
	}

	@GetMapping("/subscribers/{id}")
	public RestResponse<?> retrieveSubscriber(@PathVariable("id") Long id) {
		final Subscriber subscriber = this.business.retrieveSubscriber(id);
		if (subscriber == null) {
			return new FailureResponse<>("Subscriber not found.", 404);
		}
		return new SuccessResponse<>(subscriber);
	}
}
