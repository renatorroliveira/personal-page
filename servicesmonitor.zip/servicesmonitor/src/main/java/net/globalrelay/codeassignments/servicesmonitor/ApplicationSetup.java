package net.globalrelay.codeassignments.servicesmonitor;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import net.globalrelay.codeassignments.servicesmonitor.monitoring.MonitoringBusiness;
import net.globalrelay.codeassignments.servicesmonitor.monitoring.ScheduledOutage;
import net.globalrelay.codeassignments.servicesmonitor.monitoring.Subscriber;
import net.globalrelay.codeassignments.servicesmonitor.notification.NotificationTypes;
import net.globalrelay.codeassignments.servicesmonitor.service.Service;
import net.globalrelay.codeassignments.servicesmonitor.service.ServiceBusiness;

@Component
public class ApplicationSetup {

	private static final Logger LOG = Logger.getLogger(ApplicationSetup.class);

	@Autowired private MonitoringBusiness monitoringBusiness;
	@Autowired private ServiceBusiness serviceBusiness;
	
	@EventListener
	public void initialize(ContextRefreshedEvent event) {
		Service googleService = this.serviceBusiness.persist(new Service("Google", "www.google.com", 443));
		this.monitoringBusiness.persist(new Subscriber("Renato (E-mail)", NotificationTypes.EMAIL, "renatorro@comp.ufla.br", googleService));
		this.monitoringBusiness.persist(new Subscriber("Renato (Webhook)", NotificationTypes.WEBHOOK, "http://www.renatorro.com/", googleService));
		
		Service offFacebook = this.serviceBusiness.persist(new Service("Facebook", "www.facebook.com", 4430));
		Subscriber emailSub = new Subscriber("Renato (E-mail)", NotificationTypes.EMAIL, "renatorro@comp.ufla.br", offFacebook);
		emailSub.setGraceInterval(300000L); // five minutes
		this.monitoringBusiness.persist(emailSub);
		this.monitoringBusiness.persist(new Subscriber("Renato (WebHook)", NotificationTypes.WEBHOOK, "http://www.renatorro.com/", offFacebook));

		Service outageHomepage = this.serviceBusiness.persist(new Service("Homepage", "www.renatorro.com", 80));
		emailSub = new Subscriber("Renato (E-mail)", NotificationTypes.EMAIL, "renatorro@comp.ufla.br", outageHomepage);
		emailSub.setGraceInterval(600000L); // Ten minutes
		this.monitoringBusiness.persist(emailSub);
		this.monitoringBusiness.persist(new Subscriber("Renato (WebHook)", NotificationTypes.WEBHOOK, "http://www.renatorro.com/", outageHomepage));
		this.monitoringBusiness.persist(new ScheduledOutage(
			Date.from(LocalDateTime.of(2018, 12, 1, 0, 0).atZone(ZoneId.systemDefault()).toInstant()),
			Date.from(LocalDateTime.of(2018, 12, 30, 0, 0).atZone(ZoneId.systemDefault()).toInstant()),
			outageHomepage
		));
		
		Service outageOffHomepage = this.serviceBusiness.persist(new Service("Alternate SSL Homepage", "www.renatorro.com", 8443));
		emailSub = new Subscriber("Renato (E-mail)", NotificationTypes.EMAIL, "renatorro@comp.ufla.br", outageOffHomepage);
		emailSub.setGraceInterval(600000L); // Ten minutes
		this.monitoringBusiness.persist(emailSub);
		this.monitoringBusiness.persist(new Subscriber("Renato (WebHook)", NotificationTypes.WEBHOOK, "http://www.renatorro.com/", outageOffHomepage));
		this.monitoringBusiness.persist(new ScheduledOutage(
			Date.from(LocalDateTime.of(2018, 12, 1, 0, 0).atZone(ZoneId.systemDefault()).toInstant()),
			Date.from(LocalDateTime.of(2018, 12, 30, 0, 0).atZone(ZoneId.systemDefault()).toInstant()),
			outageOffHomepage
		));
		
		
		LOG.info("Application setup done.");
	}

}
