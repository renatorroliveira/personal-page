package net.globalrelay.codeassignments.servicesmonitor.monitoring;

import java.util.List;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

import net.globalrelay.codeassignments.servicesmonitor.service.Service;
import net.globalrelay.codeassignments.servicesmonitor.service.ServiceBusiness;

@Component
public class MonitoringJob {
	private static final Logger LOG = Logger.getLogger(MonitoringJob.class);
	
	@Autowired private ApplicationContext context;
	@Autowired private MonitoringBusiness monitoringBusiness;
	@Autowired private ServiceBusiness serviceBusiness;
	@Autowired private ThreadPoolTaskExecutor taskExecutor;
	
	@Scheduled(initialDelay=5000, fixedRate=1000)
	public void execute() {
		try {
			List<Service> servicesToPoll = this.serviceBusiness.listForMonitoring();
			servicesToPoll.forEach(this::dispatchServiceCheck);
		} catch (Exception e) {
			LOG.error("Unexpected error occurred.", e);
		}
	}
	
	protected void dispatchServiceCheck(Service service) {
		this.taskExecutor.execute(new ServiceStatusChecker(service, this.monitoringBusiness, this.serviceBusiness, context));
	}
}
