package net.globalrelay.codeassignments.servicesmonitor.notification;

public enum NotificationTypes {
	NONE((subscriber, context) -> {}),
	EMAIL(new EmailNotifier()),
	WEBHOOK(new WebHookNotifier());
	
	private final Notifier notifier;
	private NotificationTypes(Notifier notifier) {
		this.notifier = notifier;
	}
	
	public Notifier getNotifier() {
		return this.notifier;
	}
}
