package net.globalrelay.codeassignments.servicesmonitor.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.view.RedirectView;

import net.globalrelay.codeassignments.servicesmonitor.monitoring.MonitoringBusiness;
import net.globalrelay.codeassignments.servicesmonitor.monitoring.ScheduledOutage;
import net.globalrelay.codeassignments.servicesmonitor.monitoring.Subscriber;
import net.globalrelay.codeassignments.servicesmonitor.service.Service;
import net.globalrelay.codeassignments.servicesmonitor.service.ServiceBusiness;

@Controller
public class WebController {

	@Autowired private ServiceBusiness serviceBusiness;
	@Autowired private MonitoringBusiness monitoringBusiness;
	
	@RequestMapping("/")
	public Object index(Model model) {
		model.addAttribute("services", this.serviceBusiness.listAll());
		return "index";
	}

	@RequestMapping("/service/{id}/details")
	public Object index(Model model, @PathVariable("id") Long id) {
		Service service = this.serviceBusiness.retrieve(id);
		if (service == null) {
			throw new PageNotFoundException();
		}
		model.addAttribute("service", service);
		model.addAttribute("outages", service.getOutages());
		model.addAttribute("subscribers", service.getSubscribers());
		return "serviceDetails";
	}

	@RequestMapping("/outage/{id}/delete")
	public Object deleteOutage(@PathVariable("id") Long id) {
		ScheduledOutage outage = this.monitoringBusiness.deleteOutage(id);
		return new RedirectView(String.format("/service/%d/details", outage.getService().getId()));
	}

	@RequestMapping("/subscriber/{id}/delete")
	public Object deleteSubscriber(@PathVariable("id") Long id) {
		Subscriber sub = this.monitoringBusiness.deleteSubscriber(id);
		return new RedirectView(String.format("/service/%d/details", sub.getService().getId()));
	}

}
