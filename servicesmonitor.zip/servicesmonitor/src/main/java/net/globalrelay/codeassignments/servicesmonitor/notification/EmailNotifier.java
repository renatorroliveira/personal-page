package net.globalrelay.codeassignments.servicesmonitor.notification;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.jboss.logging.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

import net.globalrelay.codeassignments.servicesmonitor.monitoring.Subscriber;
import net.globalrelay.codeassignments.servicesmonitor.service.Service;

public class EmailNotifier implements Notifier {
	private static final Logger LOG = Logger.getLogger(WebHookNotifier.class);

	private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy hh:mm:ss");
	
	@Override
	public void notify(Subscriber subscriber, ApplicationContext context) {
		try {
			final Service service = subscriber.getService();
			final JavaMailSender sender = context.getBean(JavaMailSender.class);
			final SimpleMailMessage email = new SimpleMailMessage();
			email.setFrom("Services Monitor <noreply@globalrelay.net>");
			email.setTo(subscriber.getNotificationParams());
			email.setSubject(String.format("[WARN] Monitored service %s down", service.getLabel())); 
			email.setText(String.format("The following monitored service is down:\n\n%s\nHost: %s:%d\nDown since: %s\nLast verified: %s\n\n",
				service.getLabel(),
				service.getHost(),
				service.getPort(),
				this.formatter.format(LocalDateTime.ofInstant(new Date(service.getLastDownTime()).toInstant(), ZoneId.systemDefault())),
				this.formatter.format(LocalDateTime.ofInstant(new Date(service.getLastPoll()).toInstant(), ZoneId.systemDefault()))
			));
			
			sender.send(email);
			LOG.infof("E-mail sent: %s", email.toString());
		} catch (Exception e) {
			LOG.errorf(e, "Failed to send e-mail notification: %s", subscriber.getNotificationParams());
		}
	}
	
}
