# Services Monitoring Application
This application was developed following those specifications from the code assignment.
It was developed using Java 1.8 and some Java tools and frameworks such as:

- Maven 3.5 for dependecy management, building and packaging the application.
- Spring Boot 2.1.1 for the web interface and API to interact with the app features.
- JPA with H2 in-memory database for demonstrating the capability of storing all the app information to a database.
- JUnit, Hamcrest, Mockito and Spring Test framework to develop the test suite provided.

All the specified features were developed in the app. The web frontend was developed to show
the information that is stored on the database. All the create, retrieve and delete operations
are available via REST endpoints.

There are two options of notifications for interested subscribers, e-mail and webhooks.
To make the e-mail sending work as expected, some SMTP server configuration must be provided
on the file `src/main/resources/application.properties` before building and running the app.

## Running the application
Just build with maven and run with Java, in the command line, go to the app folder and run:

```shell
$ mvn clean package
$ java -jar target/
```

The application will listen on port 8080, and can be accessed on the URL:
[http://localhost:8080/](http://localhost:8080/).

## Available REST endpoints

### Service
There are endpoints for the service entity on the base URL
[http://localhost:8080/api/services](http://localhost:8080/api/services),
 that has the following structure:
```json
{
    "label": "Google",
    "lastPoll": 1545001334868,
    "lastDownTime": 1545000873845,
    "up": true,
    "host": "www.google.com",
    "port": 443,
    "created": "2018-12-16 08:54:33",
    "id": 1
}
```
There are the following endpoints available:

#### Create new service
```json
POST http://localhost:8080/api/services
{
    "label": "Google",
    "host": "www.google.com",
    "port": 443
}

// Example response
{
  "data": {
    "label": "Google",
    "lastPoll": 1545002081686,
    "lastDownTime": 1545002081686,
    "up": true,
    "host": "www.google.com",
    "port": 443,
    "created": "2018-12-16 08:54:33",
    "id": 1
  },
  "success": true,
  "status": 200
}
// Example CURL command
curl -XPOST 'http://localhost:8080/api/services' -H 'Content-type: application/json' -d '{label:"Google", host: "www.google.com", port: 443}'
```

#### Find all services
```json
GET http://localhost:8080/api/services

// Example response
{
  "data": [
    {
      "label": "Google",
      "lastPoll": 1545002263868,
      "lastDownTime": 1545002081686,
      "up": true,
      "host": "www.google.com",
      "port": 443,
      "created": "2018-12-16 08:54:33",
      "id": 1
    },
    {
      "label": "Facebook",
      "lastPoll": 1545002280868,
      "lastDownTime": 1545000903870,
      "up": false,
      "downReason": "connect timed out",
      "host": "www.facebook.com",
      "port": 4430,
      "created": "2018-12-16 08:54:33",
      "id": 4
    }
  ],
  "success": true,
  "status": 200
}
// Example CURL command
curl -XGET 'http://localhost:8080/api/services'
```

#### Retrieve a specific service
```json
GET http://localhost:8080/api/services/{SERVICE_ID}

// Example response
{
  "data": {
    "label": "Google",
    "lastPoll": 1545002263868,
    "lastDownTime": 1545002081686,
    "up": true,
    "host": "www.google.com",
    "port": 443,
    "created": "2018-12-16 08:54:33",
    "id": 1
  },
  "success": true,
  "status": 200
}
// Example CURL command
curl -XGET 'http://localhost:8080/api/services/1'
```

#### Delete a specific service
```json
DELETE http://localhost:8080/api/services/{SERVICE_ID}

// Example response
{
  "data": {
    "label": "Google",
    "lastPoll": 1545002263868,
    "lastDownTime": 1545002081686,
    "up": true,
    "host": "www.google.com",
    "port": 443,
    "created": "2018-12-16 08:54:33",
    "id": 1
  },
  "success": true,
  "status": 200
}
// Example CURL command
curl -XDELETE 'http://localhost:8080/api/services/1'
```


### Subscriber
There are endpoints for the subscriber entity on the base URL
[http://localhost:8080/api/subscribers](http://localhost:8080/api/subscribers),
 that has the following structure:
```json
{
    "label": "Renato (E-mail)",
    "notificationType": "EMAIL",
    "notificationParams": "renatorro@comp.ufla.br",
    "notificationSent": false,
    "pollingInterval": 30000,
    "graceInterval": 60000,
    "service": {
        // ... other service fields
        "id": 1
    },
    "id": 2
}
```

#### Create new subscriber
```json
POST http://localhost:8080/api/subscribers
{
    "label": "Renato (E-mail)",
    "notificationType": "EMAIL",
    "notificationParams": "renatorro@comp.ufla.br",
    "pollingInterval": 30000,
    "graceInterval": 60000,
    "service": {
        "id": 1
    }
}

// Example response
{
  "data": {
    "label": "Renato (E-mail)",
    "notificationType": "EMAIL",
    "notificationParams": "renatorro@comp.ufla.br",
    "notificationSent": false,
    "pollingInterval": 30000,
    "graceInterval": 60000,
    "service": {
      "label": "Google",
      "lastPoll": 1545003056276,
      "lastDownTime": 1545002841251,
      "up": true,
      "host": "www.google.com",
      "port": 443,
      "created": "2018-12-16 09:27:21",
      "id": 1
    },
    "id": 16
  },
  "success": true,
  "status": 200
}
// Example CURL command
curl -XPOST 'http://localhost:8080/api/subscribers' -H 'Content-type: application/json' -d '{"label": "Renato (E-mail)","notificationType": "EMAIL","notificationParams": "renatorro@comp.ufla.br","pollingInterval": 30000,"graceInterval": 60000,"service": {"id": 1}}'
```

#### Find all subscribers
```json
GET http://localhost:8080/api/subscribers

// Example response
{
  "data": [
    {
      "label": "Renato (E-mail)",
      "notificationType": "EMAIL",
      "notificationParams": "renatorro@comp.ufla.br",
      "notificationSent": false,
      "pollingInterval": 30000,
      "graceInterval": 60000,
      "service": {
        "label": "Google",
        "lastPoll": 1545003118275,
        "lastDownTime": 1545002841251,
        "up": true,
        "host": "www.google.com",
        "port": 443,
        "created": "2018-12-16 09:27:21",
        "id": 1
      },
      "id": 2
    },
    {
      "label": "Renato (Webhook)",
      "notificationType": "WEBHOOK",
      "notificationParams": "http://www.renatorro.com/",
      "notificationSent": false,
      "pollingInterval": 30000,
      "graceInterval": 60000,
      "service": {
        "label": "Google",
        "lastPoll": 1545003118275,
        "lastDownTime": 1545002841251,
        "up": true,
        "host": "www.google.com",
        "port": 443,
        "created": "2018-12-16 09:27:21",
        "id": 1
      },
      "id": 3
    }
  ],
  "success": true,
  "status": 200
}
// Example CURL command
curl -XGET 'http://localhost:8080/api/subscribers'
```

#### Retrieve a specific subscriber
```json
GET http://localhost:8080/api/subscribers/{SERVICE_ID}

// Example response
{
  "data": {
    "label": "Renato (E-mail)",
    "notificationType": "EMAIL",
    "notificationParams": "renatorro@comp.ufla.br",
    "notificationSent": false,
    "pollingInterval": 30000,
    "graceInterval": 60000,
    "service": {
      "label": "Google",
      "lastPoll": 1545003180276,
      "lastDownTime": 1545002841251,
      "up": true,
      "host": "www.google.com",
      "port": 443,
      "created": "2018-12-16 09:27:21",
      "id": 1
    },
    "id": 2
  },
  "success": true,
  "status": 200
}
// Example CURL command
curl -XGET 'http://localhost:8080/api/subscribers/2'
```

#### Delete a specific subscriber
```json
DELETE http://localhost:8080/api/subscribers/{SERVICE_ID}

// Example response
{
  "data": {
    "label": "Renato (E-mail)",
    "notificationType": "EMAIL",
    "notificationParams": "renatorro@comp.ufla.br",
    "notificationSent": false,
    "pollingInterval": 30000,
    "graceInterval": 60000,
    "service": {
      "label": "Google",
      "lastPoll": 1545003180276,
      "lastDownTime": 1545002841251,
      "up": true,
      "host": "www.google.com",
      "port": 443,
      "created": "2018-12-16 09:27:21",
      "id": 1
    },
    "id": 2
  },
  "success": true,
  "status": 200
}
// Example CURL command
curl -XDELETE 'http://localhost:8080/api/subscribers/2'
```


### Scheduled Outage
There are endpoints for the outage entity on the base URL
[http://localhost:8080/api/outages](http://localhost:8080/api/outages),
that has the following structure:
```json
{
    "created": "2018-12-16 08:54:33",
    "begin": "2018-12-01 12:00:00",
    "end": "2018-12-30 12:00:00",
    "service": {
        // ... other service fields
        "id": 1
    },
    "id": 10
}
```

#### Create new outage
```json
POST http://localhost:8080/api/outages
{
    "begin": "2018-12-01 12:00:00",
    "end": "2018-12-30 12:00:00",
    "service": {
        "id": 1
    }
}

// Example response
{
  "data": {
    "created": "2018-12-16 09:36:38",
    "begin": "2018-12-01 12:00:00",
    "end": "2018-12-30 12:00:00",
    "service": {
      "label": "Google",
      "lastPoll": 1545003396274,
      "lastDownTime": 1545002841251,
      "up": true,
      "host": "www.google.com",
      "port": 443,
      "created": "2018-12-16 09:27:21",
      "id": 1
    },
    "id": 17
  },
  "success": true,
  "status": 200
}
// Example CURL command
curl -XPOST 'http://localhost:8080/api/outages' -H 'Content-type: application/json' -d '{"begin": "2018-12-01 12:00:00","end": "2018-12-30 12:00:00","service": {"id": 1}}'
```

#### Find all outages
```json
GET http://localhost:8080/api/outages

// Example response
{
  "data": [
    {
      "created": "2018-12-16 09:27:21",
      "begin": "2018-12-01 12:00:00",
      "end": "2018-12-30 12:00:00",
      "service": {
        "label": "Homepage",
        "lastPoll": 1545003427276,
        "lastDownTime": 1545002841263,
        "up": true,
        "host": "www.renatorro.com",
        "port": 80,
        "created": "2018-12-16 09:27:21",
        "id": 7
      },
      "id": 10
    }
    {
      "created": "2018-12-16 09:36:38",
      "begin": "2018-12-01 12:00:00",
      "end": "2018-12-30 12:00:00",
      "service": {
        "label": "Google",
        "lastPoll": 1545003427276,
        "lastDownTime": 1545002841251,
        "up": true,
        "host": "www.google.com",
        "port": 443,
        "created": "2018-12-16 09:27:21",
        "id": 1
      },
      "id": 17
    }
  ],
  "success": true,
  "status": 200
}
// Example CURL command
curl -XGET 'http://localhost:8080/api/outages'
```

#### Retrieve a specific outage
```json
GET http://localhost:8080/api/outages/{SERVICE_ID}

// Example response
{
  "data": {
    "created": "2018-12-16 09:36:38",
    "begin": "2018-12-01 12:00:00",
    "end": "2018-12-30 12:00:00",
    "service": {
      "label": "Google",
      "lastPoll": 1545003489276,
      "lastDownTime": 1545002841251,
      "up": true,
      "host": "www.google.com",
      "port": 443,
      "created": "2018-12-16 09:27:21",
      "id": 1
    },
    "id": 17
  },
  "success": true,
  "status": 200
}
// Example CURL command
curl -XGET 'http://localhost:8080/api/outages/17'
```

#### Delete a specific outage
```json
DELETE http://localhost:8080/api/outages/{SERVICE_ID}

// Example response
{
  "data": {
    "created": "2018-12-16 09:36:38",
    "begin": "2018-12-01 12:00:00",
    "end": "2018-12-30 12:00:00",
    "service": {
      "label": "Google",
      "lastPoll": 1545003489276,
      "lastDownTime": 1545002841251,
      "up": true,
      "host": "www.google.com",
      "port": 443,
      "created": "2018-12-16 09:27:21",
      "id": 1
    },
    "id": 17
  },
  "success": true,
  "status": 200
}
// Example CURL command
curl -XDELETE 'http://localhost:8080/api/outages/17'
```
